<?php include "includes/_header.php" ?>

<div class="panel panel-primary">
	<div class="panel-heading">
		<h3 class="panel-title">Sorry, you need to be logged in to do that!</h3>
	</div>
	<div class="panel-body">
		<h3>Please <a href="login.php">Sign In</a></h3>




<?php include "includes/_footer.php" ?>
