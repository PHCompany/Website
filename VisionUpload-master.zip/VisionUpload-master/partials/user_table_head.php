<thead>
<tr>
    <th>FULL NAME</th>
    <th>USERNAME</th>
    <th>EMAIL</th>
</tr>
</thead>